package model;

/**
 * Represents one color channel type in ann RGB image.
 */
public enum ColorChannel {
  RED, GREEN, BLUE;
}
