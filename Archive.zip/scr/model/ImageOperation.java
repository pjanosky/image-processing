package model;

public interface ImageOperation {
  Image apply(Image image);
}


//class Filter extends ImageOperation {
//  Filter(?? matrix)
//}