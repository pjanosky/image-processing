package model;

/**
 * Represents one color channel in and RGB image.
 */
public enum ColorChannel {
  RED, GREEN, BLUE;
}
