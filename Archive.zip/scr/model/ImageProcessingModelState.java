package model;

public interface ImageProcessingModelState {

  Image getCurrentImage();
}
